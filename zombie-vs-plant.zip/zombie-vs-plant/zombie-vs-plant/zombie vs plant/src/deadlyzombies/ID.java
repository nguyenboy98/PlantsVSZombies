package deadlyzombies;

public enum ID {
zombies(),plants(), bullet();
}
